package basic

import org.apache.spark.HashPartitioner
import org.apache.spark.sql.SparkSession
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object WrdCnt {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("testing")
      .master("local[5]")
      .getOrCreate()
    val path = "D:\\sample_file\\"
    val datardd1 = spark.read.textFile(path+"blogtext2.txt")
    val datardd = datardd1.repartition(3)
    val splitrdd = datardd.rdd.flatMap(f => f.split(" "))
    val filterrdd = splitrdd.filter(a => !a.equals("tiger"))                                  // just for knowledge
    val tuplerdd = filterrdd.map(word => (word,1))
    val filterrdd2 = tuplerdd.filter( a => (a._1.startsWith("a") || ! a._1.startsWith("b")))  // just for knowledge
    //Hash-partition before transformation over pair RDD
    //Before perform any transformation we should shuffle same key data at the same worker so for that we use Hash-partition to shuffle data and make partition using the key of the pair RDD let see the example of the Hash-Partition data
    val haspartitionrdd = tuplerdd.partitionBy(new HashPartitioner(4))
    val finalreducebykey = haspartitionrdd.reduceByKey(_+_)
    val finalgroupbykey  = filterrdd2.groupByKey().map(t => (t._1, t._2.sum))
    finalgroupbykey.foreach(x => println(x))
    finalgroupbykey.collect()
    //x => println(x)
    scala.io.StdIn.readLine()
  }

}
