package scalapractise

object Others {
  def main(args: Array[String]): Unit = {

    //The Stream is a lazy lists where elements are evaluated only when they are needed.
    // This is a scala feature. Scala supports lazy computation. It increases performance of our program.
   //*********App in Scala
    //A helper class, named App, is provided by Scala that provides the main method and its members together.
    //App trait allows Objects to be turned into executable programs quickly.


  }

}
