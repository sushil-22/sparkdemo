package basic

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{avg, col, count, max, sum,row_number}

object AggrFuncExample {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("").master("local").getOrCreate()

    import spark.implicits._
    val simpleData =  Seq(("James","Sales","NY",90000,34,10000),
      ("Michael","Sales","NY",86000,56,20000),
      ("Robert","Sales","CA",81000,30,23000),
      ("Maria","Finance","CA",90000,24,23000),
      ("Raman","Finance","CA",99000,40,24000),
      ("Scott","Finance","NY",83000,36,19000),
      ("Jen","Finance","NY",79000,53,15000),
      ("Jeff","Marketing","CA",80000,25,18000),
      ("Kumar","Marketing","NY",91000,50,21000)
    )
    val df = simpleData.toDF("employee_name","department","state","salary","age","bonus")
    val filt_col = df.columns.filter(f => f.startsWith("emp")).map(m => col(m))
    df.select(filt_col:_*)
    df.select(df.columns(1))
    //df.show()
    val W1 = Window.partitionBy("department","state").orderBy($"state".asc)
    val W2 = Window.orderBy($"sum_sal".asc)
    df.groupBy("department","state")
      .agg(
        sum("salary").as("sum_sal"),
        sum("bonus").as("sum_bon"),
        avg("salary").as("avg_sal"),
        count("state").as("cnt_stat"),
        count("department").as("cnt_dept")
      ).withColumn("rnk", row_number().over(W2)).filter("rnk>=1 and rnk<4").show()

    df.groupBy(col("department"),col("state")).agg(sum(col("salary")).as("sumofcol"))

    val df2 = Seq(
      ("Alice", "Math", 90),
      ("Alice", "Science", 80),
      ("Bob", "Math", 85),
      ("Bob", "Science", 95),
      ("Charlie", "Math", 70),
      ("Charlie", "Science", 75)
    ).toDF("name", "subject", "score")
    val groupedDf = df2.groupBy("name").agg(avg("score"), max("score"), count("subject"))
    groupedDf.join(df2, df2("name")===groupedDf("name"),"inner")
  }
}
