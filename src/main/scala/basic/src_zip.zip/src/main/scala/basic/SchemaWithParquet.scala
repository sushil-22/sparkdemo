package basic


import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types.{ArrayType, DateType, IntegerType, StringType, StructType}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

object SchemaWithParquet {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder().appName("testing").master("local").getOrCreate()
    import spark.implicits._
    val data = Seq(
      (1, "Chandler", "Pasadena", "US"),
      (2, "Monica", "New york", "USa"),
      (3, "Phoebe", "Suny", "USA"),
      (4, "Rachael", "St louis", "United states of America"),
      (5, "Joey", "LA", "Ussaa"),
      (6, "Ross", "Detroit", "United states")
    )
    val col = Seq("id", "name", "city", "country")
    val df1 = data.toDF(col:_*)
    // here ordero of column also matter, means order of column of schema and order of column of files both should same
    val schema_1 = new StructType().add("id",IntegerType).add("name",StringType).add("city",StringType).add("DOB",StringType)      // here DOB is not column name and its value will be null
    val schema_2 = new StructType().add("id",IntegerType).add("name",StringType)   // here all the column of table are not present
    val schema_3 = new StructType()

    // spark.read.format("").schema(schema_1).option("","").load()
    spark.read.schema(schema_1).parquet("some location").show()  // here dob value is null
    spark.read.schema(schema_1).parquet("some location").show()  // here only two column will read

  }

}
