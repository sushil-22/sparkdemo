package RDDExample

import org.apache.spark.sql.SparkSession

object ReadMultipleFiles {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("").master("local").getOrCreate()
    import spark.implicits._
    val rdd1 =spark.read.textFile("D:\\sample_file\\text_files\\loc_1\\emp_01.txt")
    rdd1.foreach(f => println(f))
    val header = rdd1.first()
    val withoutheader = rdd1.filter( line => !line.contains(header))
    withoutheader.foreach(f => println(f))
  }

}
