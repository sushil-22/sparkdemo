package scalapractise

object HighOrderFunctionExample {
  def main(args: Array[String]): Unit = {
    def add: (Int, Int) => Int = mathOperation("addition")
    def mul: (Int, Int) => Int = mathOperation("multiplication")
    def div: (Int, Int) => Int = mathOperation("division")
    def sub: (Int, Int) => Int = mathOperation("subtraction")
    println(add(10, 5))
    //-------------------------Example 2----------------------------
    val domainName = "www.example.com"
    def getURL = urlBuilder(ssl=true, domainName)
    val endpoint = "users"
    val query = "id=1"
    val url = getURL(endpoint, query)
    println(url)
  }
  // A function which return a function
  //Return type (Int, Int) => Int indicates that a function is returned
  def mathOperation(name: String): (Int, Int) => Int = (x: Int, y: Int) => {
    name match {
      case "addition" => x + y
      case "multiplication" => x * y
      case "division" => x/y
      case "subtraction" => x - y
    }
  }
  def urlBuilder(ssl: Boolean, domainName: String): (String, String) => String = {
    val schema = if (ssl) "https://" else "http://"
    (endpoint: String, query: String) => s"$schema$domainName/$endpoint?$query"
  }

}
