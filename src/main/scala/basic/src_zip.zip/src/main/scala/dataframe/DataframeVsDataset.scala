package dataframe

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
//https://blog.knoldus.com/spark-type-safety-in-dataset-vs-dataframe/

case class Employ(name: String, age: Int, id: Int, department: String)
object DataframeVsDataset {
  def main(args: Array[String]): Unit = {
    val empData = Seq(Employ("A", 24, 132, "HR"),
      Employ("B", 26, 131, "Engineering"),
      Employ("C", 25, 135, "Data Science"))
    val spark = SparkSession.builder().appName("").master("local[3]").getOrCreate()
    import spark.implicits._
    val empRDD = spark.sparkContext.makeRDD(empData)
    val empDataFrame = empRDD.toDF()
    val empDataset = empRDD.toDS()
    empDataFrame.repartition(200,col("name"),col("age")).sort(col("name"),col("age"))
    //empDataFrame.show()
    //empDataset.show()
    //Applying lambda function on DataFrame and Dataset
    empDataFrame.show()
    val empDatasetResult = empDataset.filter( emp => emp.age >24)
    empDataFrame.map(emp => emp.getAs[Int]("age") * 2)
    //empDataFrame.filter( emp => emp.age > 24)
    // Above line give "error: value age is not a member of org.apache.spark.sql.Row"
    empDataFrame.filter( emp => emp.getAs[Int]("id") > 2)
    //to access column value from Row object we need to typecast
    //simply giving column name won’t allow us to access column value out there

    //DataFrame and Dataset behave differently when querying on non-existing column


  }
}
