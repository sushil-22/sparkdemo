package scalapractise

object Apply_Unapply_Example {
  def main(args: Array[String]): Unit = {
    // Defining apply method
    def apply(firstname: String, lastname: String) =
    {
      firstname +"kumari"+ lastname
    }
    // Defining unapply method
    def unapply(x: String): Option[(String, String)] =
    {
      // Applying a method split
      val y = x.split("kumari")
      if (y.length == 2)
      {
        Some(y(0), y(1))
      }
      else
        None
    }
    // Displays output
    println ("The Apply method returns : " +apply("Nidhi", "Singh"))
    println ("The Unapply method returns : " +unapply("NidhikumariSingh"))
  }

}
