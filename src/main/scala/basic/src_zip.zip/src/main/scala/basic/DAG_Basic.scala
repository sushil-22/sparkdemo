package basic

import org.apache.spark.sql.SparkSession

object DAG_Basic {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("").master("local[6]").config("spark.sql.shuffle.partitions",200).getOrCreate()
    import spark.implicits._

    val df1 = spark.range(1, 100000000)
    val df1mod = df1.selectExpr("id * 2 as id")
    val df1repart = df1mod.repartition(8)

    val df2 = spark.range(1, 100000000,2)
    val df2mod = df2.selectExpr("id * 5 as id")
    val df2reprt = df2mod.repartition(9)

    val joineddf= df1repart.join(df2reprt,"id")

    val sumdf = joineddf.selectExpr("sum(id) as sum")

    sumdf.show(11)

    scala.io.StdIn.readLine()


  }

}
