package dataframe

import org.apache.spark.sql.SparkSession

object Physical_Logical_Plan {
  def showPlan(spark: SparkSession): Unit = {
    val itemsSchema = Seq("id", "name", "price")
    val ordersSchema = Seq("id", "itemid", "count")
    val item = Seq(
      ("0", "Tomato", "2.0"),
      ("1", "Watermelon", "5.5"),
      ("2", "pineapple", "7.0")
    )
    val order = Seq(
      ("100", "0", "1"),
      ("100", "1", "1"),
      ("101", "2", "3"),
      ("102", "2", "8")
    )
    import spark.implicits._
    val itemdf = item.toDF(itemsSchema: _*)
    val orderdf = order.toDF(ordersSchema: _*)
    itemdf.printSchema()
    orderdf.printSchema()
    itemdf.createGlobalTempView("ITEMS")
    orderdf.createGlobalTempView("ORDERS")

    itemdf.join(orderdf,itemdf("id") === orderdf("itemid"),"left").explain(extended = false)

    scala.io.StdIn.readInt()


  }
}