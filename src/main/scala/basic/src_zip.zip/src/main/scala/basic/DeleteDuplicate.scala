package basic

import org.apache.spark.sql.SparkSession

object DeleteDuplicate {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .master("local")
      .appName("testing")
      .getOrCreate()
    import spark.implicits._
    val data = Seq(("tom","tim","tom.tim@example.com"),
      ("Catherine","Abel","catherine.abel@example.com"),
      ("Kim","Abercrombie","kim.abercrombie@example.com"),
      ("Kim","Abercrombie","kim.abercrombie@example.com"),
      ("Kim","Abercrombie","kim.abercrombie@example.com"),
      ("Hazem","Abolrous","hazem.abolrous@example.com"),
      ("Hazem","Abolrous","hazem.abolrous@example.com"),
      ("Humberto","Acevedo","humberto.acevedo@example.com"),
      ("Humberto","Acevedo","humberto.acevedo@example.com"),
      ("Pilar","Ackerman","pilar.ackerman@example.com"))

    val col = Seq("fname", "lname", "email")
    val emp=data.toDF(col:_*)
    emp.show()

    emp.createOrReplaceTempView("emp2")
    //spark.sql("select * from (select *,row_number() over (partition by fname,lname,email order by fname,lname,email) as rnk from emp2) as s where rnk=1").show()

    //spark.sql("select * from (select *,row_number() over (partition by fname,lname,email order by fname,lname,email) as rnk from emp2) as s where rnk=1").show()

    //spark.sql("""select *,row_number() over(partition by fname order by fname) as rnk from emp2""").show()
    spark.sql("""select *,row_number() over(partition by fname, lname, email order by fname,lname,email) as rnk from emp2""").show()


  }

}
