package basic

import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object ConcatExample {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("testing")
      .master("local")
      .getOrCreate()
    val data = Seq(("James","A","Smith","2018","M",3000),
      ("James","A","Smith","2018","M",7000),
      ("Michael","Rose","Jones","2010","M",4000),
      ("Robert","K","Williams","2010","M",4000),
      ("Maria","Anne","Jones","2005","F",4000),
      ("Jen","Mary","Brown","2010","",-1)
    )

    val columns = Seq("fname","mname","lname","dob_year","gender","salary")
    import spark.sqlContext.implicits._
    val df = data.toDF(columns:_*)
    df.show(false)

    df.select(concat(col("fname"),lit("~"),col("mname"),col("lname")).as("fullname")).show()

    df.select($"fname",$"lname",concat($"fname",lit(","),concat($"lname")) as("concat_col"))

    df.withColumn("fullname",concat($"fname",lit(","),concat($"lname")))

    df.withColumn("Fullname2",concat_ws("~",col("fname"),col("lname")))

    df.withColumn("fullname3",concat(col("fname"),lit(","),col("lname")))

    df.createOrReplaceTempView("df2")
    // example of aggregation
    spark.sql("select fname,collect_set(salary) from df2 group by fname")

  }
}
