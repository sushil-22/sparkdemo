package basic

import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

object Read_PhysicalPlan {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .config("spark.sql.sources.bucketing.enabled",true)
      .appName("testing")
      .master("local")
      .getOrCreate()

    val df1 = spark.range(1,100000,2)
    val df2 = df1.selectExpr("id * 2 as id")
    val df3 = df2.repartition(7)
    val coldf = df3.coalesce(2)
    val df4 = spark.range(1,100000,4)
    val df5 = df4.selectExpr("id * 3 as id")
    val df6 = df5.repartition(9)
    val joindf = df4.join(df6,"id")

    df1.write.bucketBy(11,"id").sortBy("id").mode("overwrite").format("paquet").saveAsTable("df1_new")
    df2.write.bucketBy(11,"id").sortBy("id").mode("overwrite").format("paquet").saveAsTable("df2_new")

    df1.write.bucketBy(11,"id").sortBy("id").mode("overwrite").parquet("/tmp/sushil/output/df1_res")
    df2.write.bucketBy(11,"id").sortBy("id").mode("overwrite").parquet("/tmp/sushil/output/df2_res")
  }


}
