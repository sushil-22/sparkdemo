package dataframe

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, dense_rank, lag, lead, ntile, percent_rank, rank, row_number,asc,desc,format_string,format_number,regexp_replace,explode,split}
import org.apache.spark.sql.types.{StringType, StructType,IntegerType,TimestampType}
import org.apache.spark.sql.types._
import  org.apache.spark.sql.functions._

object ScenarioBased {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("testing")
      .master("local")
      .getOrCreate()
    val path="D:\\sample_file\\"
    //distance_travelled_eachday(spark)
    //average_distance_between_city(spark)
    //read_file_with_multipledelimeter(spark, path)
    //compute_distance_between_statn(spark,path)
    //add_leading_zero(spark,path)
    //find_maximum_modified_files(spark,path)
    //textFileVswholeTextFile(spark,path)
    //selfjoinexample(spark,path)
    //datasetFormCSVfile(spark,path)
    //test(spark,path)
    //cumulative_example(spark,path)
    //readbankdata(spark,"")
    splitColumntoMultipleColumn(spark,"")

  }

  def distance_travelled_eachday(spark: SparkSession): Unit = {
    import spark.implicits._
    val data1 = Seq(
      ("Car1", "Day1", 20),
      ("Car1", "Day2", 50),
      ("Car1", "Day3", 200),
      ("Car2", "Day1", 5),
      ("Car3", "Day1", 15),
      ("Car3", "Day2", 35),
      ("Car3", "Day3", 70),
      ("Car3", "Day4", 95)
    )
    val cardata = data1.toDF("car","day","KM")
    cardata.show()
    cardata.printSchema()
    val schema = new StructType()
      .add("car_name",StringType)
      .add("day",StringType)
      .add("distance_travelled",IntegerType)
    val windowsec2 = Window.partitionBy("car").orderBy("day")
    cardata.withColumn("new_col",lag("KM",1,22).over(windowsec2))
      .withColumn("new_lag",lag("KM",2,0).over(windowsec2))
      .withColumn("desired_cal",col("KM")-lag("KM",1,0).over(windowsec2)).show()
    cardata.createOrReplaceTempView("cardata")
    //spark.sql("select *,lag(KM,1,0) over (partition by car order by day desc) as lag from cardata").show()
  }

  def average_distance_between_city(spark: SparkSession): Unit = {
    import spark.implicits._
    val data=Seq(
      ("A","B","21"),
      ("B","A","28"),
      ("A","B","19"),
      ("C","D","15"),
      ("C","D","17"),
      ("D","C","16"),
      ("D","C","18")
    )
    val citydata = data.toDF("Source_city","destincation_city","distance")
    citydata.show()
    citydata.printSchema()
    citydata.createOrReplaceTempView("citydata")
    spark.sql("select * from (select Source_city,destincation_city,count(*),row_number() over(order by Source_city) as row_id from citydata group by Source_city,destincation_city) as S").show()
  }

  def read_file_with_multipledelimeter(spark: SparkSession,path: String): Unit = {
    val dftag = spark.read.option("header", "false").option("delimeter",'|').option("inferSchema", "false")
      .csv(path+"multipledelemeter.csv").toDF()
    dftag.show()

    val readtext = spark.read.textFile(path+"multipledelemeter.csv").toDF()
    readtext.show()
    readtext.rdd.map(row => row.toString()).foreach(x => println(x))
  }

  def compute_distance_between_statn(spark: SparkSession,path: String): Unit = {
    val df1 = spark.read.option("header", "true")
      .option("inferSchema", "true")
      .option("timestampFormat","dd/MM/yyyy HH:mm")
      .csv(path+"bus_data.csv")
    df1.show()
    df1.printSchema()
    val spec = Window.partitionBy(df1("bus_id")).orderBy("time")
    val df_withRow = df1.withColumn("rom_num",row_number().over(spec))
    df_withRow.createOrReplaceTempView("df1")
    df_withRow.createOrReplaceTempView("df2")
    val joineddata = spark.sql("select df1.stn_name as src,df2.stn_name as dest,df1.time as st_tm,df2.time as ed_tm, unix_timestamp(df2.time) - unix_timestamp(df1.time) as dur from df1 join df2 on df1.bus_id = df2.bus_id and df2.rom_num> df1.rom_num").show()
  }
  def add_leading_zero(spark: SparkSession,path: String): Unit = {
    val df1 = spark.read.csv(path+"pipe_delimited.csv").toDF("chk")
    df1.show()
    df1.printSchema()
    val replace_df = df1.withColumn("values",regexp_replace(col("chk"),"(.*?\\|){5}","$0-"))
    replace_df.withColumn("explode_val",explode(split(col("values"),"\\|-"))).show()

  }

  def find_maximum_modified_files(spark: SparkSession,path: String): Unit = {
    val df1 = spark.read.option("header", "true")
      .option("inferSchema", "true")
      .csv(path + "files_modify_detail.csv")
    df1.show()
    df1.createOrReplaceTempView("df1")

    //spark.sql("select date_modify,SUBSTR(file_name, instr(file_name, '.')+1) as ext ,count(*) from df1 group by date_modify,SUBSTR(file_name, instr(file_name, '.')+1) order by date_modify desc").show()
    spark.sql("select date_modify,max(cnt) from (select date_modify,SUBSTR(file_name, instr(file_name, '.')+1) as ext ,count(*) as cnt from df1 group by date_modify,SUBSTR(file_name, instr(file_name, '.')+1) order by date_modify desc)t group by date_modify").show()
  }
  def textFileVswholeTextFile(spark: SparkSession,path: String): Unit = {
    val rdd1 = spark.sparkContext.textFile("D:\\sample_file\\wholetextfiledemo\\*",3)
    //val rdd1 = spark.sparkContext.textFile("D:\\sample_file\\wholetextfiledemo\\employee_*.txt")
    val wholetxtfile = spark.sparkContext.wholeTextFiles("D:\\sample_file\\wholetextfiledemo\\employee_*.txt",4)
    // this will return rdd of type tuple (path, value)
    //wholetxtfile.foreach(f => println(f._1 + f._2))
    wholetxtfile.foreach(f => println(f))
    //println("total record..."+rdd1.count())
  }
  def findodeOfTree(spark: SparkSession,path: String): Unit = {
    val df1 = spark.read.option("header", "true")
      .option("inferSchema", "true")
      .csv(path + "reporting.csv")
    df1.show()
    df1.createOrReplaceTempView("df1")
    spark.sql("""select node_id,parent_id, case when parent_id is Null then 'Root'
        |when parent_id is Null and node_id IN ('1','2') then 'Inner'
        |else 'leaf'
        |end as res from df1""".stripMargin).show()
  }

  def selfjoinexample(spark: SparkSession,path: String): Unit = {
    val df1 = spark.read.option("header", "true").option("inferSchema", "true").csv("D:\\sample_file\\" + "selfjoin.csv")
    df1.show()
    df1.createOrReplaceTempView("df1")
    spark.sql("select E.FullName as emp,M.FullName as mngr,E.Salary as empsal,M.Salary as mngrsal from df1 E inner join df1 M on E.ManagerId = M.Id and E.Salary > M.Salary")
    spark.sql("select E.FullName as emp,M.FullName as mngr,E.Salary as empsal,M.Salary as mngrsal from df1 E left join df1 M on E.ManagerId = M.Id and E.Salary > M.Salary").show()
  }
  def datasetVsDataframe(spark: SparkSession,path: String): Unit = {
    //https://medium.com/knoldus/difference-between-rdd-df-and-ds-in-spark-3dea12dea0c
  }
  def showtransactionDate(spark: SparkSession,path: String): Unit = {
    val df1 = spark.read.option("header", "true").option("inferSchema", "true").csv(path + "transaction.csv")
    df1.show()
    df1.printSchema()
    df1.createOrReplaceTempView("df1")
    spark.sql("select * from (select *,sum(trns_amt) over(partition by account_no order by transaction_date) as final_balance, case when sum(trns_amt) over(partition by account_no order by transaction_date) >=1000 then 1 else 0 end as bal_flag  from(select *,case when debit_credit='debit' then transaction_amt*-1 else transaction_amt end as trns_amt from df1)b )c where bal_flag=1").show()

  }
  def cumulative_example(spark: SparkSession,path: String): Unit = {
    val dftag = spark.read.option("header", "true").option("inferSchema", "true").csv(path+"cumulative.csv")
    dftag.show()
    dftag.createOrReplaceTempView("patient")
    spark.sql("SELECT pat_id,dept_id,ins_amt, SUM(ins_amt)  over (PARTITION BY DEPT_ID ORDER BY pat_id desc) as cumsum  FROM   patient  ORDER  BY dept_id")
    spark.sql("select pat_id, sum(ins_amt) over(order by pat_id) as total_sum from patient order by dept_id")
    spark.sql("select pat_id, sum(ins_amt) over(partition by pat_id) as total_sum from patient order by pat_id").show()

  }
  def test(spark: SparkSession,path: String): Unit = {
    val dftag = spark.read.option("header", "true").option("inferSchema", "true").csv("/tmp/sushil/files/OnlineRetail.csv")
    val df2 = dftag.repartition(5)
    val df4 = df2.filter("country != 'United Kingdom'")
    val df5  = df4.groupBy("Country").sum("UnitPrice")
    df2.collect()
  }
  def findFamousBrowser(spark: SparkSession,path: String): Unit = {
    val dftag = spark.read.option("header", "true").option("inferSchema", "true").csv("D:\\sample_file\\"+"weblog.csv")
    dftag.createOrReplaceTempView("dftag")
    val df1 =spark.sql("select *,from_unixtime(unix_timestamp(sessionStart), 'MM') as mnth from dftag")
    df1.show()
    df1.createOrReplaceTempView("df1")
    spark.sql("select os,browser,mnth,count(1) from df1 group by os,browser,mnth order by count(1)").show()
  }
  def readbankdata(spark: SparkSession,path: String): Unit = {
    val df1 = spark.read.option("header", "true").option("inferSchema", "true").csv("D:\\sample_file\\"+"bankdata.csv")
    //df1.show()
    df1.createOrReplaceTempView("df1")
    spark.sql(""" select * from df1 where
              from_unixtime(unix_timestamp(time_stamp, 'yyyy-MM-dd HH:mm:ss'), 'HH:mm') > '10:00'
              and from_unixtime(unix_timestamp(time_stamp, 'yyyy-MM-dd HH:mm:ss'), 'HH:mm') < '14:00'
              and from_unixtime(unix_timestamp(time_stamp, 'yyyy-MM-dd HH:mm:ss'), 'yyyyMM') = '202212' """.stripMargin)
    val df2 = df1.select(col("transaction_id"),date_format(col("time_stamp"),"MM/dd/yy HH:mm:ss").as("time_stamp"))
  }
   def splitColumntoMultipleColumn(spark: SparkSession, path: String): Unit = {
     import spark.implicits._
     val columns = Seq("name","address")
     val data = Seq(("Robert, Smith", "1 Main st, Newark, NJ, 92537"),("Maria, Garcia","3456 Walnut st, Newark, NJ, 94732"))
     var dfFromData = spark.createDataFrame(data).toDF(columns:_*)
     val newDF = dfFromData.map(f=>{
       val c1 = f.getAs[String](0).split(",")
       val c2 = f.getAs[String](1).split((","))
       (c1(0),c1(1),c2(0),c2(1),c2(2))
     })
     val findf = newDF.toDF("fname","lname","add1","add2","add3")
     // reverse of above steps
     val findfnew = findf.map(row => {
       val c1 = row.getAs[String](0) + row.getAs[String](1)
       val c2 = row.getAs[String](2)
       val c3 = row.getAs[String](3)
       val c4 = row.getAs[String](4)
       (c1,c2,c3,c4)
     })
     findfnew.show()
     val r = findfnew.select("_1").rdd.map(r => r(0)).collect()
     r.foreach(r => println(r))
   }
}
