package dataframe

import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types.{ArrayType, StringType, StructType}
import org.apache.spark.sql.functions.array_contains
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.catalyst.plans.Inner

object JoinExample {

  def joindataframe(spark: SparkSession): Unit ={

    val emp = Seq((1,"Smith","10"),
      (2,"Rose","20"),
      (3,"Williams","10"),
      (4,"Jones","10"),
      (5,"Brown","40"),
      (6,"Brown","50")
    )
    val empColumns = Seq("emp_id","name","emp_dept_id")
    import spark.sqlContext.implicits._
    val empDF = emp.toDF(empColumns:_*)
    empDF.show(false)

    val dept = Seq(("Finance",10),
      ("Marketing",20),
      ("Sales",30),
      ("IT",40)
    )
    val deptColumns = Seq("dept_name","dept_id")
    val deptDF = dept.toDF(deptColumns:_*)
    deptDF.show(false)


    val address = Seq((1,"1523 Main St","SFO","CA"),
      (2,"3453 Orange St","SFO","NY"),
      (3,"34 Warner St","Jersey","NJ"),
      (4,"221 Cavalier St","Newark","DE"),
      (5,"789 Walnut St","Sandiago","CA")
    )
    val addColumns = Seq("emp_id","addline1","city","state")
    val addDF = address.toDF(addColumns:_*)
    addDF.show(false)

    val df2=empDF.join(deptDF,empDF("emp_dept_id") === deptDF("dept_id"),"Left" )
    df2.show()
    df2.repartition(11)
    println("partition size of emp df "+empDF.rdd.getNumPartitions)
    println("partition size of dept df "+deptDF.rdd.getNumPartitions)
    println("partition size of address df "+addDF.rdd.getNumPartitions)
    println("partition size after join "+df2.rdd.getNumPartitions)

    df2.write.mode("overwrite").parquet("/BDE/sushil/out/")


    scala.io.StdIn.readInt()

  }

}
