package scalapractise

object VaiableExample {
  def main(args: Array[String]): Unit = {

    var compname = "TCS"
    val empname = "Suresh"
    compname = "Infi"       // re assignment is  possible here
    //empname = "Sohan"   ---> re assignment is not possible here

    println(compname+".."+empname)
  }

}
