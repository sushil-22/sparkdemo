package scalapractise

object TupleExample {
  def main(args: Array[String]): Unit = {
    //Tuple is a collection of elements. Tuples are heterogeneous data structures, i.e.,
    // is they can store elements of different data types. A tuple is immutable,unlike an array in scala which is mutable.
    // Scala tuples combine a Finite number of items together so that the programmer can Pass a tuple around as a Whole.


    val detail = (12, "Suresh", "kumar", 2200.23, true)
    println(detail._1)
    println(detail._2)
    println(detail._3)
    println(detail._4)
    println(detail._5)

    // The foreach method takes a function as parameter and applies it to every element in the collection
    detail.productIterator.foreach(i => println(i))
  }

}
