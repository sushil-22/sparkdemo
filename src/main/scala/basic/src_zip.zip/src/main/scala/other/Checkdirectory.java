package other;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;


public class Checkdirectory {
    static ArrayList<String> al = new ArrayList<String>();
    public static void main(String[] args) throws IOException  {
        System.out.println("hi...");
        File ff =new File("D:\\svnbackup_1\\Docs");
        printAllJavaFiles(ff);
        for (String dir: al){
            if(new File(dir).list().length<1){
                System.out.println("cd "+dir);
                System.out.println("touch .gitkeep");
            }
        }
    }

    public static void printAllJavaFiles(File directory) {
        if (directory.isDirectory()) {
            File[] subDirectories = directory.listFiles();
            for (File file : subDirectories) {
                if(file.isDirectory()) {
                    al.add(file.toString());
                }
                printAllJavaFiles(file);          // Recusion call
            }
        }else {
            //System.out.println(directory);
        }
    }



    }


