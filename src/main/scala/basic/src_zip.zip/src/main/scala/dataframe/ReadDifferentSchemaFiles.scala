package dataframe

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.{IntegerType, StringType, StructType}
import org.apache.spark.sql.functions.lit

object ReadDifferentSchemaFiles {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("").master("local[3]").getOrCreate()

    ///BDE/sushil/files/emp1.csv
    val emp1df = spark.read.csv("D:\\sample_file\\emp1.csv")
    val emp2df = spark.read.csv("D:\\sample_file\\emp2.csv")
    val emp1_schema = new StructType()
      .add("id",StringType)
      .add("name",StringType)
      .add("salary",StringType)
      .add("age",StringType)

    val emp2_schema = new StructType()
      .add("id",StringType)
      .add("name",StringType)
      .add("salary",StringType)
      .add("age",StringType)
      .add("gender",StringType)
    val emp1dfwithSchema = spark.createDataFrame(emp1df.rdd, StructType(emp1_schema))
    val emp2dfwithSchema = spark.createDataFrame(emp2df.rdd, emp2_schema)

    val emp1withgender = emp1dfwithSchema.withColumn("gender",lit("NULL"))


    val finaldf = emp1dfwithSchema.join(emp2dfwithSchema, emp1dfwithSchema("id") === emp2dfwithSchema("id" ) &&
      emp1dfwithSchema("name") === emp2dfwithSchema("name" ),"fullouter")
    emp1dfwithSchema.show()
    emp2dfwithSchema.show()
    emp2dfwithSchema.union(emp1withgender).show()
    finaldf.show()
    // another way of reading table from external schema
    //spark.read.schema(emp1_schema).csv("D:\\sample_file\\emp1.csv").show()


  }

}
