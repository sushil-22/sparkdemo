package basic

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, dense_rank, lag, lead, ntile, percent_rank, rank, row_number}
import org.apache.spark.sql.types.{ArrayType, DateType, IntegerType, StringType, StructType}
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel


object Testing {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("").master("local").getOrCreate()
    val path="D:\\sample_file\\"
    val dftag = spark.read.option("header", "true").option("inferSchema", "true").csv(path+"cricket.csv")
    dftag.show()
    dftag.createOrReplaceTempView("df")
    spark.sql("select concat_ws(' VS ',d1.Team,d2.Team) from df d1 join df d2 on d1.ID != d2.ID and d1.ID < d2.ID").show()
  }

}
