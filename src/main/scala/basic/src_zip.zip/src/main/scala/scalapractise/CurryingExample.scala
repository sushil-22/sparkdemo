package scalapractise

object CurryingExample {
  def main(args: Array[String]): Unit = {
    val str1:String = "Hello, "
    val str2:String = "Scala!"
    val str3:String = "language"

    println( "str1 + str2 = " +  stringconcat(str1,str2,"") )
    println(strConcat(str1)(str2)(str3))
  }

  def stringconcat(s1: String,s2: String,s3: String): String = {
    s1 + s2 + s3
  }
  def strConcat(s1: String)(s2: String)(s3: String): String ={
      s1 + s2 + s3
  }
}
