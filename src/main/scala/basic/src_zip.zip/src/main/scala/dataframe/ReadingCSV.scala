package dataframe

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.storage.StorageLevel

import scala.util.Random

object ReadingCSV {
  def main(args: Array[String]): Unit = {
    val path="D:\\sample_file\\"
    val spark = SparkSession.builder().appName("").master("local[3]").getOrCreate()
    val schema = new StructType()
      .add("InvoiceNo",StringType).add("StockCode",StringType)
      .add("Description",StringType).add("Quantity",StringType)
      .add("InvoiceDate",DateType).add("UnitPrice",StringType)
      .add("CustomerID",StringType).add("Country",StringType)

    val dftag = spark.read.option("header", "true").option("inferSchema", "true").csv(path+"OnlineRetail.csv")
    val df2 = dftag.withColumn("InvoiceDate",from_unixtime(unix_timestamp(col("InvoiceDate"),"MM/dd/yyyy HH:mm"),"yyyy-MM"))
    dftag.createOrReplaceTempView("data")
    dftag.persist(StorageLevel.MEMORY_AND_DISK)
    dftag.repartition(11,col("InvoiceNo"),col("InvoiceDate")).sort(col("InvoiceNo"),col("InvoiceDate"))
    dftag.select("*")
    dftag.selectExpr("InvoiceNo","StockCode")
    dftag.filter(col("InvoiceNo") === "536365")
    dftag.filter("InvoiceNo IN ('536365','536367')")
    val v1 = "536365"; val v2 = "85123A"
    dftag.filter(col("InvoiceNo") === s"$v1" && col("StockCode") =!= s"$v2")
    // aggregate data
    val df3=dftag.groupBy(col("Country")).agg(sum(col("Quantity")).as("qnt_sum"),sum(col("UnitPrice")).as("price_sum"))
    //df3.show()
    df3.createOrReplaceTempView("df3")
    spark.sql("select Country,sum(price_sum) from df3 group by Country")
    spark.sql(s"select InvoiceNo,StockCode,from_unixtime(unix_timestamp(InvoiceDate,'yyyy-MM-dd hh:mm:ss'),'dd/MM/yyyy') as newdate from data where InvoiceNo='$v1'").show()
    //spark.sql("select Country,qnt_sum,price_sum,sum(price_sum) from df3").show()
    val fun = filtermydf(dftag)("Country")(_)
  }
  def filtermydf(df: DataFrame)(col1: String)(value: String): DataFrame = {
    df.filter(col(s"$col1") === s"$value")
  }
}

























