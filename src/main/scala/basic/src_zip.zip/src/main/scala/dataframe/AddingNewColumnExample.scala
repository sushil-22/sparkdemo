package dataframe

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions.{lit}

import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types.{StringType}
import org.apache.spark.sql.functions._
object AddingNewColumnExample {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .master("local")
      .appName("testing")
      .getOrCreate()
    import spark.sqlContext.implicits._
    val data = Seq(("111",50000),("222",60000),("333",40000),("333",20000))
    val df = data.toDF("EmpId","Salary")
    df.show()
    df.createOrReplaceTempView("df")
    val viewname="df"
    val col_nm="Salary"
    spark.sql(s"select *,CONCAT_WS('~',EmpId,$col_nm) as concated from ${viewname}").show()        //CONCAT_WS finction
    //df.withColumn("copycolumn",col("Salary")*2).show()
    //df.withColumn("Salary_increased",col("Salary").cast(StringType)).show()
    spark.sql("select *, case when Salary<=20000 then 'fail' when Salary>20000 and Salary<=40000 then 'medium' when Salary>40000 and Salary<=50000 then 'high'  else 'other' END AS result from df").show()

    df.withColumn("category",
       when(col("Salary")<30000,"A")                                // lit not added
      .when(col("Salary")>=30000 && col("Salary") <= 40000,"B")     // here called coumn by using col
      .otherwise(lit("B").cast(StringType))).show()


    df.withColumn("typedLit_seq",typedLit(Seq(1, 2, 3)))
      .withColumn("typedLit_map",typedLit(Map("a" -> 1, "b" -> 2)))
      .withColumn("typedLit_struct",typedLit(("a", 2, 1.0)))
      .drop(col("Salary")).show()
  }

}
