package scalapractise

object ClosureExample {

  //A closure is a function, whose return value depends on the value of one or more variables declared
  // outside this function.
  def main(args: Array[String]): Unit = {
    println(multiplier(12))
    println(multiplier(2))
  }

  //Now factor has a reference to a variable outside the function but in the enclosing scope.
  // The function references factor and reads its current value each time.
  // If a function has no external references, then it is trivially closed over itself.
  // No external context is required.
  var fat = 12
  val multiplier = (i: Int) => i * fat +3

}
