package dataframe

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.col

object PartialAppliedOrCurrying {

  def main(args: Array[String]): Unit = {
    val path="D:\\sample_file\\"
    val spark = SparkSession.builder().appName("").master("local[3]").getOrCreate()
    val dftag = spark.read.option("header", "true").option("inferSchema", "true").csv(path+"OnlineRetail.csv").toDF()
    //dftag.show(22)

    val filterByCountry = filterByColumnValue("Country") _
    val filteredData = filterByCountry(dftag,"United Kingdom")
    filteredData.show()

  }
  def filterByColumnValue(column: String)(data: DataFrame, value: String): DataFrame = {
    data.filter(col(column) === value)
  }

}
