package scalapractise

object OptionExample {

  //Scala tries to solve null pointer exception using Option
  //Options are scala container that are used to test presence or absence of any value.
  //Option provides type safty alternative to specify null value in java
  def main(args: Array[String]): Unit = {

    println(fraction(22,3).get)
    println(fraction(22,0))  // return will None
  }
  // Return type of function is Option with double
  def fraction(num: Double, dem: Double): Option[Double] = {
    if (dem == 0) None
    else
      Some(num/dem)
  }

}
