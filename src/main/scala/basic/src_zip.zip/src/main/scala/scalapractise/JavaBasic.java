package scalapractise;

import java.util.HashMap;
import java.util.Map;

public class JavaBasic {

    static int fact =1;
    static int[] myarr = {10, 20, 30, 40, 50};
    public static void main(String[] args) {
        //System.out.println("Factorial of 5 is "+factorial(5));
        //System.out.println("Max element is "+findMaxNumArray(myarr));
        //reverseString("animal");
        //swaptwoNumber(12,14);
        //System.out.println(findSecondHighest(myarr));
        //printFibonacciSeries(10);
        //getDistinctCharecter("aabbbccddeeff");
        //reverseNumber();
        //reverseString2();
        reverseStringIgnoreSpecialChar();
    }
    public static void reverseString(String str){
        StringBuilder sb = new StringBuilder();
        char[] mychar = str.toCharArray();
        for(int i=mychar.length-1; i>=0; i--){
            sb.append(mychar[i]);
        }
        System.out.print(sb.toString());
    }
    // Reverse String without using StringBuilder
    public static void reverseString2(){
        String str1 = "abcde";
        System.out.println(str1);
        char[] str = str1.toCharArray();
        char c;
        for(int i=0, j = str.length-1 ; i <= str.length/2 && j >= str.length/2 ; i++, j--){
            System.out.println("i >>"+i+" j>>>"+j);
            c = str[i];
            str[i]= str[j];
            str[j] = c;
        }
        for(char c2 : str){
            System.out.print(c2+",");
        }
    }

    public static void reverseStringIgnoreSpecialChar(){
        String str1 = "abc$de";
        System.out.println(str1);
        char[] str = str1.toCharArray();
        int i = 0, j = str.length-1;
        char temp;
        while (i < j){
            if(!Character.isAlphabetic(str[i]))
                i++;
            if(!Character.isAlphabetic(str[j]))
                j--;
            else{
                temp = str[i];
                str[i] = str[j];
                str[j] = temp;
            }
        }
        for(char c2 : str)
            System.out.print(c2+",");
        System.out.print("done");
    }

    public static int factorial(int num) {
        if(num == 0)
            return 1;
        else
            fact = num * factorial(num -1);
        System.out.println("fact is-"+fact);
        return fact;
    }
    public static int findMaxNumArray(int[] num) {
        int max = myarr[0];
        for(int i=0; i<myarr.length; i++){
            if (myarr[i] > max){
                max = myarr[i];
            }
        }
        return max;
    }
    public static void printPattern(){
        for(int i=1 ; i<=4 ; i++ ){
            for(int j =4 ; j>=i ; j--) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
    public static void printPattern2(){
        for (int i=0 ; i <=4 ; i++){
            for (int j= 4 ; j<=i ; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
    public static void swaptwoNumber(int a, int b){
        b = a + b;
        a = b - a;
        b = b - a;
        System.out.printf("a is %d, b is %d", a, b);
    }

    public  static Boolean StringContainsVowels(String str){
        return str.toLowerCase().matches(".*[a,e,i,o,u].*");
    }

    public static Boolean checkPrime(int num){
        int i = 2;
        if(num == 0 || num == 1)
            return false;
        if(num == 2)
            return true;
        while ( i <= num/2){
            if (num % i == 0)
                return false;
        }
        return true;
    }
    public static void printFibonacciSeries(int cnt){
        int a=0;
        int b=1;
        int c=1;
        for(int i=1 ; i<=10 ; i++){
            c = a + b;
            a = b;
            b = c;
            System.out.print(c+",");
        }
    }
    public static int printFibonacciSeriesRecursion(int count){
        // worning wrong
        int fibo=1;
        if (count <= 1)
            return count;
        fibo = printFibonacciSeriesRecursion(count -1) + printFibonacciSeriesRecursion( count-2);
        System.out.print(fibo+",");
        return fibo;
    }
    public static boolean checkPalindromeString(String str){
        boolean result = true;
        for(int i=0 ; i<=str.length()/2 ; i++) {
            if(str.charAt(i) != str.charAt(str.length()-i-1))
                result = false;
            break;
        }
        return result;
    }
    public static int findSecondHighest(int[] myarr) {
        int highest = Integer.MIN_VALUE;
        int secHigh = Integer.MIN_VALUE;
        for (int i : myarr) {
            if (i > highest) {
                secHigh = highest;
                highest = i;
            }
        }
        return secHigh;
    }
    //get distinct characters and their count in a String
    public static void getDistinctCharecter(String str){
        char[] myarr = str.toCharArray();
        Map<Character,Integer> charcount = new HashMap<Character, Integer>();
        for (char c : myarr){
            if(charcount.containsKey(c))
                charcount.put(c, charcount.get(c)+1);
            else
                charcount.put(c,1);
        }
        System.out.println(charcount);
    }
    public static void reverseNumber(){
        int num = 1234;
        int rem = 0;
        int rev=0;
        while (num > 0){
            rem = num % 10;
            num = num / 10;
            rev = rev * 100 + rem;
        }
        System.out.println(rev);
    }

}
