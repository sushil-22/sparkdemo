package scalapractise

object StreamExample {

  def main(args: Array[String]): Unit = {
    //The Stream is a lazy lists where elements are evaluated only when they are needed.
    // This is a scala feature. Scala supports lazy computation. It increases performance of our program.
    val stream = 20 #:: 30 #:: 45 #:: 343 #:: 123 #:: Stream.empty
    println(stream)
    print("Take first 2 numbers from stream = ")
    stream.take(2).print()
    println()
    print("Take first 3 numbers from stream = ")
    stream.take(3).print()
  }
}
