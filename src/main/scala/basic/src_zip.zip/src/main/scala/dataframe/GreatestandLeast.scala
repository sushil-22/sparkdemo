package dataframe

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object GreatestandLeast {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("testing")
      .master("local")
      .getOrCreate()
    val data2 = Seq(
      ("Chandler",33,11,55),
      ("Monica",55,67,12),
      ("Phoebe",91,99,11),
      ("Rachael",65,11,77),
      ("Joey",55,98,45),
      ("Ross",45,90,45)
    )
    import spark.implicits._
    val col = Seq("name", "term_1", "term_2", "term_3")
    val df1 = data2.toDF(col:_*)
    df1.withColumn("greates",greatest("term_1", "term_2", "term_3"))
      .withColumn("least",least("term_1", "term_2", "term_3")).show()
  }
// Make a UDF here
}
