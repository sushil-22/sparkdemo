package other;
import java.io.*;

public class ReadingFiles {
    public static void main(String[] args) throws Exception {

        File file = new File("C:\\Users\\sushil.kumar.saama.c\\Documents\\Shell_backup\\Finance\\Aggr\\Metafiles\\Nav_BlwrkToAggrF1.txt");
        BufferedReader br= new BufferedReader(new FileReader(file));
        BufferedWriter f_writer = new BufferedWriter(new FileWriter("C:\\Users\\sushil.kumar.saama.c\\Documents\\output.txt"));
        String st;
        while ((st = br.readLine()) != null) {
            String tok =st.split("@@")[0];
            System.out.println("select "+"'" +tok+ "' as tab,cloadym,count(*) from financeaggr."+tok+" group by cloadym union all");
            //f_writer.write(st.split("@@")[2]+"\n");
        }
        f_writer.close();
    }
}
