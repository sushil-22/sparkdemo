package other

object ReadMetafile {
  def main(args: Array[String]): Unit = {
    import scala.io.Source

    val filename = "C:\\Users\\sushil.kumar.saama.c\\Documents\\Shell_backup\\Finance\\Raw\\Mst\\Metafiles\\Nav_SrcToRawMstF4.txt"
    for (line <- Source.fromFile(filename).getLines) {
      val linenew=line
      val arr=linenew.split("@@")
      if (arr(3).contains("str_sqls<")) {
        print(arr(2)+"@@@@@@@@")
        val meta=arr(3)
        val selectStmt = meta
          .replace("str_sqls<", "REPLACE(REPLACE(REPLACE(RTRIM(LTRIM(")
          .replace(">str_sqls", ")), CHAR(10),' '), CHAR(13),' '), CHAR(9),' ')")
          .replace("integer_sqls<", "CONVERT(NVARCHAR(MAX),")
          .replace(">integer_sqls", ")")
          .replace("dateformat1_sqls<", "CONVERT(VARCHAR,")
          .replace(">dateformat1_sqls", ",121)")
          .replace("dateformat2_sqls<", "CONVERT(VARCHAR(6),")
          .replace(">dateformat2_sqls", ",112)")
          .replace("dateformat3_sqls<", "CONVERT(VARCHAR(20),")
          .replace(">dateformat3_sqls", ",20)")
          .replace("${dtrng4raw}", "2023-01-15,2023-02-14,202302,202302")
        println(selectStmt)
      }
    }
  }
}
