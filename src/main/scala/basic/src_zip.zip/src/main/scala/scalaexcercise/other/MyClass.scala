package scalaexcercise.other

object MyClass {
  println("in object")
  def apply(x: Int, y: Int): MyClass = new MyClass(x, y)


}

class MyClass(val x: Int, val y:Int)
{
  println("in class")
  def add(): Int = x + y
}
object myMain{
  def main(args: Array[String]): Unit = {
    val obj1 = MyClass.apply(2,3)
    val obj2 = MyClass(2,3)            // above two line is same
    println(obj1.add())
    println(obj2.add())
  }
}
