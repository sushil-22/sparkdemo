package dataframe

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{row_number,rank,dense_rank,percent_rank,ntile,lead,lag,col}
import org.apache.spark.sql.types.{ArrayType, DateType, StringType, StructType,IntegerType}
import org.apache.spark.sql.functions._

//https://sparkbyexamples.com/spark/spark-sql-window-functions/
object AnalyticalFunctionExample {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("testing").master("local").getOrCreate()
    import spark.implicits._

    val simpleData = Seq(("James", "Sales", 3000),
      ("Michael", "Sales", 3000),
      ("Robert", "Sales", 4200),
      ("Maria", "Finance", 3000),
      ("James", "Sales", 4200),
      ("Scott", "Finance", 3000),
      ("Jen", "Finance", 3900),
      ("Jeff", "Marketing", 3000),
      ("Kumar", "Marketing", 3000),
      ("tom", "Marketing", 3300),
      ("Saif", "Sales", 4100),
      ("tim", "Sales", 4200)
    )
    val df = simpleData.toDF("employee_name", "department", "salary")
    df.show()
    df.createOrReplaceTempView("emp")

    // Spark Window Ranking functions
    val windspec = Window.partitionBy("department").orderBy($"salary".desc)

    val windesc = Window.partitionBy($"department").orderBy($"salary".desc)
    val winasc = Window.partitionBy($"department").orderBy($"salary".asc)
    df.withColumn("rank",col("salary")-lead($"salary",1,0).over(winasc)).show()
    val winsum = Window.partitionBy($"department").orderBy($"salary".asc)
    df.withColumn("rank",sum("salary").over(winsum))

    df.withColumn("desc",row_number().over(windesc)).withColumn("asc",row_number().over(winasc)).filter("desc==1").filter("asc==1")
    df.createOrReplaceTempView("df2")
    spark.sql("select distinct employee_name,department,salary from(select * from df2 where asc ='1' union all select * from df2 where desc ='1')t order by department,salary").show()

    //df.withColumn("row_number",row_number.over(windspec)).show()
    //spark.sql("select *, dense_rank() over(partition by department order by salary) as row_number from emp").show()
/*
    Ranking Functions
      Syntax: RANK | DENSE_RANK | PERCENT_RANK | NTILE | ROW_NUMBER
    Analytic Functions
      Syntax: CUME_DIST | LAG | LEAD | NTH_VALUE | FIRST_VALUE | LAST_VALUE
    Aggregate Functions
      Syntax: MAX | MIN | COUNT | SUM | AVG | ...
      */
    df
      .withColumn("rank", rank().over(windspec))
      .withColumn("dense_rank", dense_rank().over(windspec))
      .withColumn("row_number", row_number().over(windspec))
      .withColumn("percent_rank", percent_rank().over(windspec))
      .withColumn("ntil_col", ntile(2).over(windspec))
      .withColumn("lag_sal",lag("salary",1).over(windspec))
      .withColumn("lead_sal",lead("salary",1).over(windspec))
      .show()

    //Spark Window Analytic functions
    spark.sql("select *, lead(salary) over(partition by department order by salary desc) as nex_sal," +
      "lag(salary) over(partition by department order by salary desc) as prev_sal from emp").show()

  }

}
