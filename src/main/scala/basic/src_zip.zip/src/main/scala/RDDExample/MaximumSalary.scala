package RDDExample

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}
object MaximumSalary {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("").master("local").getOrCreate()
    import spark.implicits._
    val empdata = spark.read.textFile("D:\\sample_file\\employee_data.txt")

    // Find first record of the file
    val empheader = empdata.first()

    // Remove header from RDD
    val empdatawithoutheader = empdata.filter( line => !line.equals(empheader))
    empdatawithoutheader.foreach(word => println(word))

    println("No. of partition = " + empdatawithoutheader.rdd.partitions.size)

    val emp_sal= empdatawithoutheader.map( x => x.split(",")).map( x=> (x(5).toDouble))

    val max_sal = emp_sal.rdd.max()

    val emp_sal_asc = emp_sal.rdd.distinct().sortBy(x=> x.toDouble,true,1)  // ascding order
    emp_sal_asc.foreach(x => println(x))

    val emp_sal_des = emp_sal.rdd.distinct().sortBy(x=> x.toDouble,false,1) // descding order

    emp_sal_des.take(1).foreach(x => println(x))  // highest salary

    emp_sal_asc.take(1).foreach(x => println(x))  //lowest salary

    val sec_high_sal = emp_sal_des.zipWithIndex().filter(index => index._2 == 1).map(_._1)

    val sec_min_sal = emp_sal_asc.zipWithIndex().filter(index => index._2 == 1).map(_._1)

    sec_high_sal.foreach(x => println(x))
    sec_min_sal.foreach(x => println(x))

    // Employee who have max salary
    val salaryWithEmployeeName = empdatawithoutheader.map{x => x.split(',')}.map{x => (x(5).toDouble, x(1))}
    salaryWithEmployeeName.foreach(x => print(x))

    val maxSalaryEmployee = salaryWithEmployeeName.rdd.groupByKey.takeOrdered(1)(Ordering[Double].reverse.on(_._1))
    maxSalaryEmployee.foreach(x => println(x))

    scala.io.StdIn.readLine()

  }

}
