package basic

import org.apache.spark.sql.types.{StringType, StructType,ArrayType,MapType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.functions._
//https://sparkbyexamples.com/spark/explode-spark-array-and-map-dataframe-column/

object ExplodeExample {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("testing")
      .master("local")
      .getOrCreate()
    import spark.implicits._

    val arrayData = Seq(
      Row("James",List("Java","Scala","C++"),Map("hair"->"black","eye"->"brown")),
      Row("James",List("html","CSS","javascript"),Map("hair"->"black","eye"->"brown")),
      Row("Michael",List("Spark","Java","C++",null),Map("hair"->"brown","eye"->null)),
      Row("Robert",List("CSharp","Python",""),Map("hair"->"red","eye"->"")),
      Row("Washington",null,null),
      Row("Jeferson",List(),Map())
    )

    val arraySchema = new StructType()
      .add("name",StringType)
      .add("knownLanguages", ArrayType(StringType))
      .add("properties", MapType(StringType,StringType))

    val df = spark.createDataFrame(spark.sparkContext.parallelize(arrayData),arraySchema)
    df.printSchema()
    df.show()
    df.createOrReplaceTempView("df")

    df.select($"name",explode($"knownLanguages") as "exploded_val")
    df.select($"name",explode_outer($"knownLanguages") as "exploded_outer")
    df.select($"name",explode($"properties"))
    df.select($"name",explode_outer($"properties"))

    df.select($"name",posexplode($"knownLanguages"))
    df.select($"name",posexplode($"properties"))

    df.select($"name",posexplode_outer($"knownLanguages"))
    df.select($"name",posexplode_outer($"properties"))

    df.withColumn("new_col",explode($"knownLanguages")).groupBy("name")
      .agg(collect_list("new_col") as "aggr_col").show()
  }

}
