package basic

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions.{lit}

import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types.{StringType}
import org.apache.spark.sql.functions._

object RddExample {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("testing")
      .master("local[5]")
      .config("spark.shuffle.partitions",100)
      .getOrCreate()
    //readWordCount(spark)
    //readWordCount(spark)
    //readmultipleDelimeterFile(spark)
    mixOperationRdd(spark)
  }
  def basic(spark: SparkSession) : Unit = {
    import spark.implicits._
    val rangeRDD = spark.range(1, 300)
    val evenoddrdd = rangeRDD.map(x => if (x % 2 == 0) ("even", x) else ("odd", x))
    val filterrdd = evenoddrdd.filter(x => x._1 == "even")
    filterrdd.foreach(x => println(x))
    val evenrdd = rangeRDD.filter(x => x % 2 == 0)
    evenoddrdd.rdd.reduceByKey(_+_).foreach(x => println(x))
    evenoddrdd.foreach(x => println(x))
  }
  def readmultipleDelimeterFile(spark: SparkSession): Unit = {
    import spark.implicits._
    val rawrdd = spark.read.textFile("D:\\sample_file\\samplefile2.txt")
    rawrdd.show()
    val rawrdd2 = rawrdd.map(x => if (x.toString.contains("|")) x.toString.replace("|", ",") else x)
    import spark.implicits._
    val df2 = rawrdd2.map(f => {
      val elements = f.split(",")
      (elements(0), elements(1), elements(2), elements(3))
    })
    df2.printSchema()
    //df2.show(false)
    df2.withColumnRenamed("_1", "id").withColumnRenamed("_2", "fname").withColumnRenamed("_3", "lname").withColumnRenamed("_4", "sala")
  }
  def readWordCount(spark: SparkSession): Unit = {
    import spark.implicits._
    val rdd = spark.read.textFile("D:\\sample_file\\samplefiles.txt")
    val splitrdd = rdd.flatMap(x => x.split((" ")))
    val filterrdd = splitrdd.filter(word => word.trim.equals("tiger"))
    val keyval = filterrdd.map(x => (x,1))
    keyval.rdd.reduceByKey(_+_).foreach(x => println(x))
    //keyval.foreach(x => println(x))
  }
  def mixOperationRdd(spark: SparkSession): Unit = {
    val data = Seq("Project","Gutenberg’s","Alice’s","Adventures","in","Wonderland","Project","Gutenberg’s","Adventures","in","Wonderland","Project","Gutenberg’s")
    val rdd=spark.sparkContext.parallelize(data)
    val rdd2 = rdd.map(x => (x,x.hashCode))
    val rdd3 = rdd2.filter(x => x._1.equals("Gutenberg"))
    val rdd4 = rdd.distinct()
    rdd4.foreach(x => println(s"value is $x"))
  }
}
